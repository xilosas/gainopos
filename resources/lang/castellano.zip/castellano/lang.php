<?php
$default = include_once "default.php";
$custom = include_once "custom.php";

return array_merge($default, $custom);