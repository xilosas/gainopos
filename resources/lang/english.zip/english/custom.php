<?php

    return [

        /*
        |--------------------------------------------------------------------------
        | Add your custom language here. This will never be overwritten by updates.
        |--------------------------------------------------------------------------
        |
        | If you would like to change any language text, please copy the key here from the default.php
        |
        */

        'hello2' => 'Hello2 updated by custom language'

    ];
